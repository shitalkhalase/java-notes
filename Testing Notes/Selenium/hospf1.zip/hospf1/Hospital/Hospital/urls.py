"""Hospital URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from hosp import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path("",views.index),
    path('admin_login/',views.admin_login,name='admin_login'),
    path("adminhome/",views.admindashboard,name="adminhome"),
    path('adminlogout/',views.admin_logout,name='adminlogout'),
    path("addPatient/",views.addpatient,name="addpatient"),
    path('shows/',views.shows,name='shows'),
    path("update/<int:id>",views.Update,name="update"),
    path("deletepatient/<int:id>",views.deletepatient,name="deletepatient"), 
    path("addDoctor/",views.addDoctor,name="addDoctor"),
    path("showDoctor/",views.showDoctor,name="showDoctor"),
    path("updateDoctor/<int:id>",views.UpdateDoctor,name="updateDocotr"),
    path("deleteDoctor/<int:id>",views.deleteDoctor,name="deleteDoctor"), 
    path('approveappointment', views.approveappointment,name='approveappointment'),
    path('approve-appointment/<int:pk>', views.approve_appointment_view,name='approve-appointment'),
    path('reject-appointment/<int:pk>', views.reject_appointment_view,name='reject-appointment'),


    path('addDealer/', views.addDealer,name='addDealer'),
    path('viewDealer/', views.viewDealer,name='viewDealer'),
    path("updateDealer/<int:id>",views.UpdateDealer,name="updateDealer"),
    path("deleteDealer/<int:id>",views.deleteDealer,name="deleteDealer"), 

    path('addMedicine/', views.addMedicine,name='addMedicine'),
    path('viewMedicine/', views.viewMedicine,name='viewMedicine'),
    path("updateMedicine/<int:id>",views.UpdateMedicine,name="updateMedicine"),
    path("deleteMedicine/<int:id>",views.deleteMedicine,name="deleteMedicine"), 

    path("SignUp/",views.SignUp,name="SignUp"),
    path('userhome/',views.userhome,name='userhome'),
    path("login/",views.user_login,name='login'),
    path("logout/",views.user_logout,name='logout'),
    path("makeappoinment/",views.makeappoinment,name="makeappoinment"),
    path("showappoinment/",views.showappoinment,name="showappoinment"),
    path("deleteappoinment/<int:id>",views.deleteappoinment,name="deleteappoinment"), 
    path("callambulance/",views.ambulance,name="callambulance"),
    path("ambulancedetails/",views.ambulancedetails,name="ambulancedetails"),
    path("deleteambulance/<int:id>",views.deleteambulance,name="deleteambulance"),
   
]
urlpatterns+=static(settings.MEDIA_URL,document_root = settings.MEDIA_ROOT)