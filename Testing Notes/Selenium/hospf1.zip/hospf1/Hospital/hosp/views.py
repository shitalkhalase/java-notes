from django.shortcuts import render,redirect,HttpResponseRedirect
from .models import *
from .forms import *
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,logout,login
# Create your views here.
def index(request):
    return render(request,"index.html")


def admin_login(request):
	error = ""
	if request.method == 'POST':
		u = request.POST['username']
		p = request.POST['password']
		user = authenticate(username=u,password=p)
		try:
			if user.is_staff:
				login(request,user)
				error = "no"
			else:
				error = "yes"
		except:
			error = "yes"
	d = {'error' : error}
	return render(request,'adminlogin.html',d)

def admindashboard(request):
    return render(request,"admin.html")

def admin_logout(request):
    if not request.user.is_staff:
	    return redirect('admin_login')
    logout(request)
    return redirect('admin_login')

def SignUp(request):
    if request.method == 'POST':
        form = Registration(request.POST)
        print(form)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/login/')
            # return redirect(signupdone)
    else:
        form = Registration()
    return render(request,'registration.html',{"form":form})

def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            form =AuthenticationForm(request=request,data=request.POST)
            if form.is_valid():
                uname=form.cleaned_data['username']
                upass=form.cleaned_data['password']
                user=authenticate(username=uname,password=upass)
                if user is not None:
                    login(request, user)
                    return HttpResponseRedirect('/userhome/')
        else:
            form=AuthenticationForm()
        return render(request,'registration/user_login.html',{'form':form})
    else:
        return HttpResponseRedirect('/userhome/')

def userhome(request):
    if request.user.is_authenticated:
        return render(request,'userhome.html',{'name':request.user})
    else:
        return HttpResponseRedirect('/login/')


def makeappoinment(request):
    if request.method == 'POST':
        appoint=AppoinmentForm(request.POST)
        print(appoint)
        if appoint.is_valid():
            appoint.save()
            return redirect('userhome')
            # return HttpResponseRedirect('/userhome/')
            # return redirect(signupdone)
    else:
        appoint = AppoinmentForm()
    return render(request,'makeappoinment.html',{"appoint":appoint})


def showappoinment(request):  
    details =Appointment.objects.all()
    return render(request,'showappoinment.html',{"details":details})



def deleteappoinment(request,id):
    del_t=Appointment.objects.get(id=id)    
    del_t.delete()

    return redirect('showappoinment')
# Approveappinment
def approveappointment(request):
    details=Appointment.objects.all().filter(status=False)
    return render(request,'approveappointment.html',{'details':details})

def approve_appointment_view(request,pk):
   details=Appointment.objects.get(id=pk)
   details.status=True
   details.save()
   return redirect('approveappointment')

def reject_appointment_view(request,pk):
   details=Appointment.objects.get(id=pk)
   details.delete()
   return redirect('approveappointment')


def ambulance(request):
    if request.method == 'POST':
        appoint=AmbulanceForm(request.POST)
        print(appoint)
        if appoint.is_valid():
            appoint.save()
            return render(request,'callambulance.html',{"appoint":appoint})
            # return redirect(signupdone)
    else:
        appoint = AmbulanceForm()
    return render(request,'callambulance.html',{"appoint":appoint})

def ambulancedetails(request):  
    details =Ambulance.objects.all()  
    return render(request,"ambulancedetails.html",{"details":details})

def deleteambulance(request,id):
    del_t=Ambulance.objects.get(id=id)    
    del_t.delete()

    return redirect('ambulancedetails')

def addpatient(request):
    if request.method =='POST': 
        details = PatientForm(request.POST)
        if details.is_valid(): 
            post = details.save(commit = False)
            post.save() 
            return redirect('shows')  
        else:
            return render(request, "addpatient.html", {'form':details}) 
    else:
        form = PatientForm(None)  
        return render(request, 'addpatient.html', {'form':form})
 
       
def shows(request):  
    patients = Patient.objects.all()  
    return render(request,"showpatient.html",{'patients':patients})


def Update(request,id):
    upd=Patient.objects.get(id=id)
    update=PatientForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect('shows')
    return render(request,"updatepatient.html",{"update":update})


def deletepatient(request,id):
    del_t=Patient.objects.get(id=id)    
    del_t.delete()

    return redirect('shows')


def addDoctor(request):
    if request.method =='POST': 
        details = DoctorForm(request.POST)
        if details.is_valid(): 
            post = details.save(commit = False)
            post.save() 
            return redirect('showDoctor')  
        else:
            return render(request, "addDoctor.html", {'form':details}) 
    else:
        form = DoctorForm(None)  
        return render(request, 'addDoctor.html', {'form':form})

  
def showDoctor(request):  
    doctors = Doctor.objects.all()  
    return render(request,"showDoctor.html",{'doctors':doctors})

def UpdateDoctor(request,id):
    upd=Doctor.objects.get(id=id)
    update=DoctorForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect('showDoctor')
    return render(request,"updateDoctor.html",{"update":update})

def deleteDoctor(request,id):
    del_t=Doctor.objects.get(id=id)    
    del_t.delete()

    return redirect('showDoctor')


def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')

# medical store of hospital
def addDealer(request):
    if request.method == 'POST':
        dealer=DealerForm(request.POST)
        print(dealer)
        if dealer.is_valid():
            dealer.save()
            return redirect('viewDealer')  
        else:
            return render(request, "addDealer.html", {' dealer': dealer}) 
    else:
        dealer =DealerForm(None)  
        return render(request, 'addDealer.html', {'dealer': dealer})


def viewDealer(request):  
    dealer = Dealer.objects.all()  
    return render(request,"viewDealer.html",{'dealer':dealer})

def UpdateDealer(request,id):
    upd=Dealer.objects.get(id=id)
    update=DealerForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect('viewDealer')
    return render(request,"updatedealer.html",{"update":update})

def deleteDealer(request,id):
    del_t=Dealer.objects.get(id=id)    
    del_t.delete()

    return redirect('viewDealer')

# Medicine
def addMedicine(request):
    if request.method == 'POST':
        medicine=MedicineForm(request.POST)
        print(medicine)
        if medicine.is_valid():
            medicine.save()
            return redirect('viewMedicine')  
        else:
            return render(request, "addMedicine.html", {'medicine': medicine}) 
    else:
        medicine=MedicineForm(None)  
        return render(request, 'addMedicine.html', {'medicine': medicine})


def viewMedicine(request):  
    medicine = Medicine.objects.all()  
    return render(request,"viewMedicine.html",{'medicine':medicine})

def UpdateMedicine(request,id):
    upd=Medicine.objects.get(id=id)
    update=MedicineForm(request.POST or None,request.FILES or None,instance=upd)
    if update.is_valid():
        update.save()
        return redirect('viewMedicine')
    return render(request,"updateMedicine.html",{"update":update})

def deleteMedicine(request,id):
    del_t=Medicine.objects.get(id=id)    
    del_t.delete()

    return redirect('viewMedicine')