from django.db import models

# Create your models here.

# Patient model
class GenderType(models.Model):
    gender = models.CharField(max_length=20)
    def __str__(self):
        return self.gender

class BloodGroup(models.Model):
    bloodgroup = models.CharField(max_length=20)
    def __str__(self):
        return self.bloodgroup 

class Patient(models.Model):
    
    Patient_Name = models.CharField(max_length=30)
    Patient_Age = models.IntegerField()
    Patient_Contact = models.IntegerField()
    Patient_Gender = models.ForeignKey(GenderType,on_delete=models.CASCADE)
    Patient_BloodGroup = models.ForeignKey(BloodGroup,on_delete=models.CASCADE,null=True)
    MedicalHistory = models.CharField(max_length=30,null=True)
    Address = models.CharField(max_length=20)
# Patient model ends here

# Doctor model
class Specilization(models.Model):
    speciality = models.CharField(max_length=20)


    def __str__(self):
        return self.speciality

class Doctor(models.Model):
    GENDER =(
    ("Male", "Male"),
    ("Female", "Femle"),
    )
    BLOODGROUP =(
    ("A+", "A+"),
    ("B+", "B+"),
    ("O+", "O+"),
    ("AB+", "AB+"),
    ("A-", "A-"),
    ("B-", "B-"),
    ("O-", "O-"),
    ("AB-","AB-"),
    )
    MARITALSTATUS =(
    ("Single","Single"),
    ("Married","Married"),
    )
    DoctorName=models.CharField(max_length=20)
    Age = models.IntegerField()
    gender = models.CharField(max_length=20,choices = GENDER,null=True)
    Contact = models.IntegerField(null=True)
    Bloodgroup = models.CharField(max_length=20,choices = BLOODGROUP,null=True)
    MaritalStatus = models.CharField(max_length=20,choices =MARITALSTATUS,null=True)
    Specilization = models.ForeignKey(Specilization,on_delete=models.CASCADE)
    ConsultationFee = models.IntegerField(null=True)
    Address = models.CharField(max_length=20,null=True)

    def __str__(self):
        return self.DoctorName
# Doctor model end here

# Appoinment model 
class Appointment(models.Model):
    DoctorName=models.ForeignKey(Doctor,on_delete=models.CASCADE)
    patientname = models.CharField(max_length=50)
    symptoms = models.CharField(max_length=100)
    date = models.DateField(null=True)
    prescription = models.CharField(max_length=200)
    status=models.BooleanField(default=False)
	
    def __str__(self):
        return self.patientname

# ambulance model

class Reason(models.Model):
    reason = models.CharField(max_length=20)
    def __str__(self):
        return self.reason
class Ambulance(models.Model):
    PatientName = models.CharField(max_length=30)
    PatientAge = models.IntegerField()
    PatientContact = models.IntegerField()
    Location = models.CharField(max_length=20)
    Disease = models.ForeignKey(Reason,on_delete=models.CASCADE)

    def __str__(self):
        return self.Patient_Name


# medical store of hospital
class Dealer(models.Model):
    dealername = models.CharField(max_length=30)
    address = models.CharField(max_length=100)
    contact =  models.IntegerField(null=True)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.email

class Medicine(models.Model):
    medicinename = models.CharField(max_length=70)
    dealername = models.CharField(max_length=30)
    description = models.CharField(max_length=100)
    price = models.IntegerField(null=True)
    stock = models.IntegerField(null=True)

    def __str__(self):
        return self.medicinename
