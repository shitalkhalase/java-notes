from django.forms import ModelForm,DateInput
from django import forms
from . models import Medicine, Patient,Doctor,Appointment,Ambulance,Dealer,Medicine
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class Registration(UserCreationForm):
    class Meta:
            
        model = User
        fields = "username","password1","password2"
    username = forms.CharField(widget=forms.TextInput())
    password1 = forms.CharField(widget=forms.PasswordInput())
    password2 = forms.CharField(widget=forms.PasswordInput())
class PatientForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Patient      
 
        # Custom fields
        fields = "__all__"

class DoctorForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Doctor      
 
        # Custom fields
        fields = "__all__"

class AppoinmentForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Appointment     
 
        # Custom fields
        fields=["DoctorName","patientname","date","symptoms"]
date = forms.DateField(widget=forms.TextInput(attrs={'type': 'date', }))  


class AmbulanceForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Ambulance      
 
        # Custom fields
        fields = "__all__"

class DealerForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Dealer      
 
        # Custom fields
        fields = "__all__"

class MedicineForm(ModelForm):
    
    class Meta:
        # write the name of models for which the form is made
        model = Medicine      
 
        # Custom fields
        fields = "__all__"