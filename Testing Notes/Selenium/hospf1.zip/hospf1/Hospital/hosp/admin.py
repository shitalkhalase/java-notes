from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Patient)
admin.site.register(GenderType)
admin.site.register(BloodGroup)
admin.site.register(Doctor)
admin.site.register(Specilization)
admin.site.register(Appointment)
admin.site.register(Ambulance)
admin.site.register(Reason)
admin.site.register(Dealer)
admin.site.register(Medicine)